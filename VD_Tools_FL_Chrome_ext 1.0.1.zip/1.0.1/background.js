chrome.runtime.onMessage.addListener(
    function (request) {
            newURL = `https://loan.vsegda-da.com/application/${request.applicationId}/form`;
            chrome.tabs.create({
                url: newURL
            });
        }
);
